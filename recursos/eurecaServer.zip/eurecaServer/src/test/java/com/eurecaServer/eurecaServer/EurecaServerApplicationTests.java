package com.eurecaServer.eurecaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurecaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
