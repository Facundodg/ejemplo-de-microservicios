package com.eurecaServer.eurecaServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurecaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurecaServerApplication.class, args);
	}

}
